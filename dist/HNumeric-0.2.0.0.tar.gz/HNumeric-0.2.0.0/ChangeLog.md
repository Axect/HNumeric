# Changelog for HNumeric

## Unreleased changes
